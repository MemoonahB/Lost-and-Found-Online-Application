
package loginvalidator;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginValidator {
    public static boolean validateLogin(String name, String email, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lostandfound?" + "user=root&password=");

            PreparedStatement pst = conn.prepareStatement("Select Name,Email,Password from login where Name=? And Email=? And Password=? ");
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, password);

            ResultSet rs = pst.executeQuery();

            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

