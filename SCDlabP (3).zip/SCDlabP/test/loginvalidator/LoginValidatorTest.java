/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginvalidator;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Moon Awan
 */
public class LoginValidatorTest {
    
//    @Test
//    public void testValidateLogin_ValidCredentials_ShouldReturnTrue() {
//        assertTrue(LoginValidator.validateLogin("validName", "validEmail", "validPassword"));
//    }

    @Test
    public void testValidateLogin_InvalidCredentials_ShouldReturnFalse() {
        assertFalse(LoginValidator.validateLogin("invalidName", "invalidEmail", "invalidPassword"));
    }
    }
    

