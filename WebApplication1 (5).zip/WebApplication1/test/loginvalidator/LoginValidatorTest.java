/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package loginvalidator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author A
 */
public class LoginValidatorTest {
    
//    @Test
//    public void testValidateLogin_ValidCredentials_ShouldReturnTrue() {
//        assertTrue(LoginValidator.validateLogin("validName", "validEmail", "validPassword"));
//    }

    @Test
    public void testValidateLogin_InvalidCredentials_ShouldReturnFalse() {
        assertFalse(LoginValidator.validateLogin("invalidName", "invalidEmail", "invalidPassword"));
    }
    }
