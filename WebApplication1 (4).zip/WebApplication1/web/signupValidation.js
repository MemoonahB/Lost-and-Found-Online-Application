var email = document.getElementsByName("email")[0];
var name1 = document.getElementsByName("name1")[0];
var password = document.getElementsByName("password")[0];



function validate() {
    var valid = true;
    var emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/; //setting email pattren
    var passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&!])[A-Za-z\d@#$%^&!]{6,8}$/;  //setting password pattren

    //email validation
    if (!emailPattern.test(email.value)) {
      //if values is not equal put red border around text fiels
        valid = false;
    } 
//password validation

    if (!passwordPattern.test(password.value)) {
        
        valid = false;
    }
   //name Validation
   
  if (!/^[A-Z][a-zA-Z]*$/.test(name1.value)) {
       
        valid = false;
    }       
    return valid;
}
