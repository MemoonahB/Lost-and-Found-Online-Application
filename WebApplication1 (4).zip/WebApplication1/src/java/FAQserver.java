import java.io.*;
import java.net.*;

public class FAQserver {

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server listening on port 12345...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Handle client request in a new thread
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)) {

            String question;
            while ((question = reader.readLine()) != null) {
                if (question.isEmpty()) {
                    System.out.println("Client sent an empty question. Ignoring.");
                    continue;
                }

                System.out.println("Received question: " + question);

                // Simulate FAQ lookup
                String answer = getAnswer(question);

                // Send the answer back to the client
                writer.println(answer);

                if (question.equalsIgnoreCase("exit")) {
                    System.out.println("Client requested to exit. Closing connection.");
                    break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String getAnswer(String question) {
        // Simulate FAQ lookup logic
        // Replace this with your actual FAQ retrieval mechanism
        if (question.equalsIgnoreCase("1. How do I file a complaint?")) {
            return "To file a complaint, please visit our website and navigate to the 'Complaints' section.";
        } else if (question.equalsIgnoreCase("2. What is the status of my complaint?")) {
            return "You can check the status of your complaint by logging into your account on our website or contacting our customer support.";
        } else if (question.equalsIgnoreCase("3. How long does it take to resolve a complaint?")) {
            return "The resolution time for complaints varies depending on the nature of the complaint. Our team is dedicated to resolving issues as quickly as possible.";
        } else {
            return "Sorry, I don't have specific information about that complaint. Please contact our customer support for assistance.";
        }
    }
}
